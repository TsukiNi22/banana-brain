
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was Config.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

# Dependencies
include(CMakeFindDependencyMacro)
find_dependency(utils 4.1.0 CONFIG REQUIRED) # The public headers include <utils/utils.hpp>

# Custom error message if the required variant isn't installed (packages libbrain-db / -as / -op)
if(WIN32)
    set(_brain_package "mingw64-libbrain") # Windows packages (MinGW sysroot)
else()
    set(_brain_package "libbrain")
endif()
file(GLOB _brain_configs "${CMAKE_CURRENT_LIST_DIR}/brainTargets-*.cmake")
if(NOT _brain_configs)
    # Header-only library (INTERFACE target): no variant to check
elseif(CMAKE_BUILD_TYPE STREQUAL "Asan" AND WIN32)
    message(FATAL_ERROR
        "No Asan version of brain with MinGW (no AddressSanitizer).\n"
        "Please build in Debug with the package '${_brain_package}-db'.\n"
    )
elseif(CMAKE_BUILD_TYPE STREQUAL "Asan")
    if(NOT EXISTS "${CMAKE_CURRENT_LIST_DIR}/brainTargets-asan.cmake")
        message(FATAL_ERROR
            "The Asan version of brain is not installed.\n"
            "Please install the package '${_brain_package}-as'.\n"
        )
    endif()

elseif(CMAKE_BUILD_TYPE STREQUAL "Debug")
    if(NOT EXISTS "${CMAKE_CURRENT_LIST_DIR}/brainTargets-debug.cmake")
        message(FATAL_ERROR
            "The Debug version of brain is not installed.\n"
            "Please install the package '${_brain_package}-db'.\n"
        )
    endif()

#elseif(CMAKE_BUILD_TYPE STREQUAL "Optimized")
else() # Default selection for noconfig
    if(NOT EXISTS "${CMAKE_CURRENT_LIST_DIR}/brainTargets-optimized.cmake" AND NOT EXISTS "${CMAKE_CURRENT_LIST_DIR}/brainTargets-noconfig.cmake")
        message(FATAL_ERROR
            "The Optimized version of brain is not installed.\n"
            "Please install the package '${_brain_package}-op'.\n"
        )
    endif()
endif()
unset(_brain_configs)
unset(_brain_package)

# Load and check tools
include("${CMAKE_CURRENT_LIST_DIR}/brainTargets.cmake")
check_required_components(brain)
