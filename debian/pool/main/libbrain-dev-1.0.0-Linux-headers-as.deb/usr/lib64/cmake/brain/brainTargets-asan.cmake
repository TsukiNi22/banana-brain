#----------------------------------------------------------------
# Generated CMake target import file for configuration "Asan".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "brain::brain" for configuration "Asan"
set_property(TARGET brain::brain APPEND PROPERTY IMPORTED_CONFIGURATIONS ASAN)
set_target_properties(brain::brain PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_ASAN "CXX"
  IMPORTED_LOCATION_ASAN "${_IMPORT_PREFIX}/lib64/libbrain_asan.a"
  )

list(APPEND _cmake_import_check_targets brain::brain )
list(APPEND _cmake_import_check_files_for_brain::brain "${_IMPORT_PREFIX}/lib64/libbrain_asan.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
