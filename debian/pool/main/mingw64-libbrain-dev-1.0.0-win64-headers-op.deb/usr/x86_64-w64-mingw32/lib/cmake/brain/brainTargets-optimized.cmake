#----------------------------------------------------------------
# Generated CMake target import file for configuration "Optimized".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "brain::brain" for configuration "Optimized"
set_property(TARGET brain::brain APPEND PROPERTY IMPORTED_CONFIGURATIONS OPTIMIZED)
set_target_properties(brain::brain PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_OPTIMIZED "CXX"
  IMPORTED_LOCATION_OPTIMIZED "${_IMPORT_PREFIX}/lib/libbrain.a"
  )

list(APPEND _cmake_import_check_targets brain::brain )
list(APPEND _cmake_import_check_files_for_brain::brain "${_IMPORT_PREFIX}/lib/libbrain.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
